if os.time() - 1748460225 > 60 then return {} end
return game:GetService('HttpService'):JSONDecode('[]')
